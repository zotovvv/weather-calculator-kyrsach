# android-calculator
A simple android calculator


![alt text][logo]

[logo]: https://github.com/eloyzone/android-calculator/blob/master/app-screencapture.gif "Screen Capture of App"